﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace bookstore
{
    class Program
    {
        struct Book
        {
            public string name;
            public string author;
            public int price;
            public string type;

        }
        struct employer
        {
            public string name;
            public string ID;
            public int phonenum;
        }









        static void Main(string[] args)
        {

            
            Console.WriteLine("check the booklist: ");
            Console.WriteLine("-----------------------------------");
            Book[] book = new Book[10];
            string [] bookInfo = File.ReadAllLines("booklist.txt");
         
        
            for(int i =0;i<bookInfo.Length;i++)
            {
                // Console.WriteLine(bookInfo[i]);
                Console.WriteLine(i);
                string commaSeparatedDate = bookInfo[i];
                string[] dataArray = commaSeparatedDate.Split(',');
                ArrayList List = new ArrayList(book);
            /*   Console.WriteLine("orginal infor");
                foreach(string u in List)
                {
                    Console.WriteLine(u + " 0");
                }*/
                book[i].name = dataArray[0];
                Console.WriteLine("book name: " + book[i].name);
                book[i].author = dataArray[1];
                Console.WriteLine("author: " + book[i].author);
                book[i].price =int.Parse( dataArray[2]);
                Console.WriteLine("price: " + book[i].price);
                book[i].type = dataArray[3];
                Console.WriteLine("type: " + book[i].type);
                Console.WriteLine("----------------------------------");
                

            }
           // List.Insert(bookInfo.Length, book[])
            for (int j = bookInfo.Length; j < 100; j++)
            {
                Console.WriteLine("which book you want to add ");
                Console.WriteLine("enter name :");
                string Bokname = Console.ReadLine();
                book[j].name = Bokname;
            }
            //修改1 完善while loop 
           /*        
            int num1 = 0;
            int total = 0;
            while ((num1<bookInfo.Length)||(num1!=' '))
            {
                Console.WriteLine("enter num choose which book you want to buy: ");
                num1 = int.Parse(Console.ReadLine());
                for (int i=0; i< bookInfo.Length; i++)
                {
                    total += book[num1].price;
                   
                    break;
                }
                Console.WriteLine("you need to pay " + total);
            }*/







            Console.WriteLine("select standard for choose book: ");
            Console.WriteLine("1.author ");
            Console.WriteLine("2.type");
            Console.WriteLine("enter a num ");
            int num = int.Parse(Console.ReadLine());
            Console.WriteLine("----------------------------------");
            while(num!=0)
            {
                if (num==1)
                {
                    Console.Write("enter author name: ");
                    string authorName = Console.ReadLine();
                    for(int i=0;i<bookInfo.Length;i++)
                    {
                        if(authorName==book[i].author)
                        {
                            Console.WriteLine("book name is "+ book[i].name);
                            Console.WriteLine("price is " + book[i].price);

                        }
                    }
                    break;
                }
                
                if (num==2)
                {
                    Console.Write("enter type of book: ");
                    string bookType = Console.ReadLine();
                    for (int i = 0; i < bookInfo.Length; i++)
                    {
                        if (bookType == book[i].type)
                        {
                            Console.WriteLine("book name is " + book[i].name);
                            Console.WriteLine("price is " + book[i].price);

                        }
                    }
                    break;
                }
                
            }

            Console.WriteLine("check the employerlist: ");
            Console.WriteLine("-----------------------------------");
            employer[] employer = new employer[10];
            string[] employerInfo = File.ReadAllLines("employerlist.txt");
           // List<string> result = employer.Split(new string[] { ',' }).ToList();
            for (int i = 0; i < employerInfo.Length; i++)
            {
                // Console.WriteLine(bookInfo[i]);
                Console.WriteLine(i);
                string commaSeparatedDate = employerInfo[i];
                string[] dataArray1 = commaSeparatedDate.Split(',');
                employer[i].name = dataArray1[0];
                Console.WriteLine("name: " + employer[i].name);
                employer[i].ID = dataArray1[1];
                Console.WriteLine("ID: " + employer[i].ID);
                employer[i].phonenum= int.Parse(dataArray1[2]);
                Console.WriteLine("phonenum " + employer[i].phonenum);
                Console.WriteLine("----------------------------------");
            }

            














        }
    }
}
